# Ivan Del Rio - Senior Data Analyst Portfolio

This portfolio contains three reproducible public-data case studies:

1. CFPB consumer complaint concentration and operational risk.
2. CMS hospital quality and measurement coverage.
3. BLS labor-market resilience, wage pressure, and forecast backtesting.

## Structure

- `analysis/build_analysis.py` - profiling, transformations, metrics, and figures.
- `analysis/portfolio_models.sql` - senior-level SQL patterns.
- `data/processed/` - compact analytical summaries.
- `dist/` - publishable multi-page website.

## Rebuild

Run `python analysis/build_analysis.py` from the project root. Raw data is not bundled in the public technical package; download current files from the official source links listed on the methodology page.

## Important interpretation note

The analyses are descriptive decision-support examples. They do not establish causality and should not be used as medical, legal, or financial advice.
