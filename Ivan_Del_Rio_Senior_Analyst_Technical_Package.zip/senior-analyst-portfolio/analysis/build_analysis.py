from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
ASSETS = ROOT / "dist" / "assets"
PROCESSED.mkdir(parents=True, exist_ok=True)
ASSETS.mkdir(parents=True, exist_ok=True)

COLORS = {
    "ink": "#122033",
    "blue": "#175CD3",
    "cyan": "#0EA5E9",
    "coral": "#F97066",
    "amber": "#F79009",
    "green": "#039855",
    "muted": "#667085",
    "grid": "#D0D5DD",
    "paper": "#F8FAFC",
}

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titlesize": 13,
    "axes.labelsize": 10,
    "axes.edgecolor": COLORS["grid"],
    "axes.labelcolor": COLORS["muted"],
    "xtick.color": COLORS["muted"],
    "ytick.color": COLORS["muted"],
    "text.color": COLORS["ink"],
    "axes.facecolor": "white",
    "figure.facecolor": "white",
    "axes.grid": True,
    "grid.color": "#E4E7EC",
    "grid.linewidth": .7,
})


def savefig(name: str):
    plt.tight_layout()
    plt.savefig(ASSETS / name, format="svg", bbox_inches="tight")
    plt.close()


def pct(v: float) -> float:
    return round(float(v) * 100, 2)


def clean_bls(path: Path) -> pd.DataFrame:
    d = pd.read_csv(path, sep="\t")
    d.columns = [c.strip() for c in d.columns]
    d["series_id"] = d["series_id"].astype(str).str.strip()
    d["period"] = d["period"].astype(str).str.strip()
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d[d["period"].str.fullmatch(r"M(0[1-9]|1[0-2])", na=False)].copy()
    d["month"] = d["period"].str[1:].astype(int)
    d["date"] = pd.to_datetime(dict(year=d["year"], month=d["month"], day=1))
    return d[["series_id", "date", "value", "footnote_codes"]]


def mape(actual: pd.Series, forecast: pd.Series) -> float:
    aligned = pd.concat([actual, forecast], axis=1).dropna()
    return float((np.abs((aligned.iloc[:, 0] - aligned.iloc[:, 1]) / aligned.iloc[:, 0])).mean() * 100)


# ---------------------------------------------------------------------------
# CFPB: Arizona consumer complaints, calendar year 2024
# ---------------------------------------------------------------------------
cfpb = pd.read_csv(RAW / "cfpb_az_complaints_2024.csv", low_memory=False)
cfpb["date_received"] = pd.to_datetime(cfpb["Date received"], utc=True, errors="coerce")
cfpb["date_sent"] = pd.to_datetime(cfpb["Date sent to company"], utc=True, errors="coerce")
cfpb["send_lag_hours"] = (cfpb["date_sent"] - cfpb["date_received"]).dt.total_seconds() / 3600
cfpb["month"] = cfpb["date_received"].dt.to_period("M").astype(str)
cfpb["timely"] = cfpb["Timely response?"].eq("Yes")

cfpb_product = (
    cfpb.groupby("Product", dropna=False)
    .agg(complaints=("Complaint ID", "count"), timely_rate=("timely", "mean"), companies=("Company", "nunique"))
    .sort_values("complaints", ascending=False)
    .reset_index()
)
cfpb_product["share"] = cfpb_product["complaints"] / len(cfpb)
cfpb_product.to_csv(PROCESSED / "cfpb_product_summary.csv", index=False)

cfpb_monthly = (
    cfpb.groupby("month")
    .agg(complaints=("Complaint ID", "count"), timely_rate=("timely", "mean"), companies=("Company", "nunique"))
    .reset_index()
)
cfpb_monthly["mom_change"] = cfpb_monthly["complaints"].pct_change()
cfpb_monthly.to_csv(PROCESSED / "cfpb_monthly_summary.csv", index=False)

cfpb_company = (
    cfpb.groupby("Company")
    .agg(complaints=("Complaint ID", "count"), timely_rate=("timely", "mean"), products=("Product", "nunique"))
    .sort_values("complaints", ascending=False)
    .reset_index()
)
cfpb_company["cumulative_share"] = cfpb_company["complaints"].cumsum() / cfpb_company["complaints"].sum()
cfpb_company.to_csv(PROCESSED / "cfpb_company_summary.csv", index=False)

top_products = cfpb_product.head(6).sort_values("complaints")
fig, ax = plt.subplots(figsize=(8.4, 4.4))
ax.barh(top_products["Product"].str.replace("Credit reporting or other personal consumer reports", "Credit reporting", regex=False), top_products["complaints"], color=COLORS["blue"])
ax.set_title("Arizona complaints are highly concentrated by product")
ax.set_xlabel("Complaints received in 2024")
ax.spines[["top", "right", "left"]].set_visible(False)
for i, value in enumerate(top_products["complaints"]):
    ax.text(value + max(top_products["complaints"]) * .012, i, f"{value:,.0f}", va="center", fontsize=9)
savefig("cfpb_product_mix.svg")

fig, ax = plt.subplots(figsize=(8.4, 4.0))
ax.plot(pd.to_datetime(cfpb_monthly["month"]), cfpb_monthly["complaints"], marker="o", linewidth=2.6, color=COLORS["blue"])
ax.fill_between(pd.to_datetime(cfpb_monthly["month"]), cfpb_monthly["complaints"], alpha=.12, color=COLORS["cyan"])
ax.set_title("Complaint volume by month")
ax.set_ylabel("Complaints")
ax.spines[["top", "right"]].set_visible(False)
savefig("cfpb_monthly.svg")


# ---------------------------------------------------------------------------
# CMS: Hospital General Information, released August 2026
# ---------------------------------------------------------------------------
cms = pd.read_csv(RAW / "cms_hospital_general_information_2026.csv", low_memory=False)
cms["rating"] = pd.to_numeric(cms["Hospital overall rating"], errors="coerce")
cms["safety_worse"] = pd.to_numeric(cms["Count of Safety Measures Worse"], errors="coerce").fillna(0)
cms["mort_worse"] = pd.to_numeric(cms["Count of MORT Measures Worse"], errors="coerce").fillna(0)
cms["readm_worse"] = pd.to_numeric(cms["Count of READM Measures Worse"], errors="coerce").fillna(0)
cms["rated"] = cms["rating"].notna()
cms["high_quality_flag"] = cms["rating"].ge(4) & cms["safety_worse"].eq(0) & cms["Emergency Services"].eq("Yes")

cms_state = (
    cms.groupby("State")
    .agg(hospitals=("Facility ID", "nunique"), rated_hospitals=("rated", "sum"), rating_avg=("rating", "mean"), high_quality=("high_quality_flag", "sum"))
    .reset_index()
)
cms_state["rating_coverage"] = cms_state["rated_hospitals"] / cms_state["hospitals"]
cms_state["high_quality_share"] = cms_state["high_quality"] / cms_state["hospitals"]
cms_state.to_csv(PROCESSED / "cms_state_summary.csv", index=False)

cms_ownership = (
    cms.groupby("Hospital Ownership", dropna=False)
    .agg(hospitals=("Facility ID", "nunique"), rated_hospitals=("rated", "sum"), rating_avg=("rating", "mean"), safety_worse_avg=("safety_worse", "mean"))
    .sort_values("hospitals", ascending=False)
    .reset_index()
)
cms_ownership["rating_coverage"] = cms_ownership["rated_hospitals"] / cms_ownership["hospitals"]
cms_ownership.to_csv(PROCESSED / "cms_ownership_summary.csv", index=False)

cms_shortlist = cms.loc[cms["high_quality_flag"], ["Facility ID", "Facility Name", "City/Town", "State", "Hospital Type", "Hospital Ownership", "rating", "safety_worse"]].sort_values(["State", "Facility Name"])
cms_shortlist.to_csv(PROCESSED / "cms_high_quality_shortlist.csv", index=False)

rating_counts = cms["rating"].value_counts().sort_index()
fig, ax = plt.subplots(figsize=(7.8, 4.3))
bars = ax.bar(rating_counts.index.astype(int).astype(str), rating_counts.values, color=["#B42318", COLORS["coral"], COLORS["amber"], COLORS["cyan"], COLORS["green"]])
ax.set_title("Overall hospital ratings among rated facilities")
ax.set_xlabel("CMS overall rating")
ax.set_ylabel("Hospitals")
ax.spines[["top", "right"]].set_visible(False)
for b, v in zip(bars, rating_counts.values): ax.text(b.get_x() + b.get_width()/2, v + rating_counts.max()*.018, f"{v:,}", ha="center", fontsize=9)
savefig("cms_rating_distribution.svg")

own_plot = cms_ownership[cms_ownership["hospitals"] >= 100].sort_values("rating_avg").tail(8)
fig, ax = plt.subplots(figsize=(8.6, 4.6))
ax.barh(own_plot["Hospital Ownership"], own_plot["rating_avg"], color=COLORS["blue"])
ax.set_xlim(1, 5)
ax.set_title("Average rating by ownership group (100+ hospitals)")
ax.set_xlabel("Average CMS overall rating")
ax.spines[["top", "right", "left"]].set_visible(False)
savefig("cms_ownership_rating.svg")


# ---------------------------------------------------------------------------
# BLS: employment, hours, earnings, and CPI time series
# ---------------------------------------------------------------------------
employment_raw = clean_bls(RAW / "bls_total_nonfarm_employment.tsv")
earnings_raw = clean_bls(RAW / "bls_private_hours_earnings.tsv")
cpi_raw = clean_bls(RAW / "bls_cpi_all_items.tsv")

series = {
    "employment": employment_raw[employment_raw["series_id"].eq("CES0000000001")].set_index("date")["value"],
    "weekly_hours": earnings_raw[earnings_raw["series_id"].eq("CES0500000002")].set_index("date")["value"],
    "hourly_earnings": earnings_raw[earnings_raw["series_id"].eq("CES0500000003")].set_index("date")["value"],
    "cpi": cpi_raw[cpi_raw["series_id"].eq("CUUR0000SA0")].set_index("date")["value"],
}
bls = pd.concat(series, axis=1).sort_index()
bls = bls.loc["2007-01-01":].copy()
bls["real_hourly_earnings"] = bls["hourly_earnings"] / bls["cpi"] * 100
for col in ["employment", "hourly_earnings", "cpi", "real_hourly_earnings"]:
    base_date = bls.loc["2019-01-01":, col].first_valid_index()
    bls[f"{col}_index"] = bls[col] / bls.loc[base_date, col] * 100
bls["employment_mom"] = bls["employment"].diff()
bls["employment_yoy"] = bls["employment"].pct_change(12)
bls["employment_change_z"] = (bls["employment_mom"] - bls["employment_mom"].rolling(36).mean()) / bls["employment_mom"].rolling(36).std()
bls.to_csv(PROCESSED / "bls_economic_timeseries.csv")

chart_bls = bls.loc["2019-01-01":, ["employment_index", "hourly_earnings_index", "cpi_index", "real_hourly_earnings_index"]].dropna(how="all")
fig, ax = plt.subplots(figsize=(9.0, 4.8))
ax.plot(chart_bls.index, chart_bls["employment_index"], label="Nonfarm employment", color=COLORS["blue"], linewidth=2.4)
ax.plot(chart_bls.index, chart_bls["hourly_earnings_index"], label="Hourly earnings", color=COLORS["green"], linewidth=2.2)
ax.plot(chart_bls.index, chart_bls["cpi_index"], label="CPI", color=COLORS["coral"], linewidth=2.2)
ax.plot(chart_bls.index, chart_bls["real_hourly_earnings_index"], label="Real hourly earnings", color=COLORS["amber"], linewidth=2.2, linestyle="--")
ax.axhline(100, color=COLORS["grid"], linewidth=1)
ax.set_title("Employment, earnings, and prices indexed to January 2019 = 100")
ax.set_ylabel("Index")
ax.legend(frameon=False, ncol=2, loc="upper left")
ax.spines[["top", "right"]].set_visible(False)
savefig("bls_indexed_trends.svg")

mom = bls.loc["2019-01-01":, "employment_mom"].dropna()
fig, ax = plt.subplots(figsize=(9.0, 4.2))
colors = np.where(mom >= 0, COLORS["blue"], COLORS["coral"])
ax.bar(mom.index, mom.values, width=25, color=colors)
ax.axhline(0, color=COLORS["ink"], linewidth=.9)
ax.set_title("Monthly change in total nonfarm employment")
ax.set_ylabel("Thousands of jobs")
ax.spines[["top", "right"]].set_visible(False)
savefig("bls_job_change.svg")

# Backtest a transparent 12-month seasonal-naive forecast against a 36-month linear trend.
emp = series["employment"].dropna().sort_index()
holdout = emp.iloc[-12:]
train = emp.iloc[:-12]
seasonal_naive = emp.shift(12).reindex(holdout.index)
x = np.arange(36)
coef = np.polyfit(x, train.iloc[-36:].values, 1)
trend_forecast = pd.Series(np.polyval(coef, np.arange(36, 48)), index=holdout.index)
forecast_metrics = {
    "seasonal_naive_mape": round(mape(holdout, seasonal_naive), 3),
    "linear_trend_mape": round(mape(holdout, trend_forecast), 3),
}


# ---------------------------------------------------------------------------
# Portfolio-wide metrics and quality checks
# ---------------------------------------------------------------------------
latest_common = bls[["employment", "hourly_earnings", "weekly_hours", "cpi"]].dropna().index.max()
latest_emp_date = emp.index.max()
latest_emp = float(emp.iloc[-1])
year_ago_emp = float(emp.loc[emp.index <= latest_emp_date - pd.DateOffset(years=1)].iloc[-1])
feb_2020 = float(emp.loc[pd.Timestamp("2020-02-01")])
recovery_candidates = emp.loc["2020-03-01":]
recovery_date = recovery_candidates[recovery_candidates >= feb_2020].index.min()

quality_checks = {
    "cfpb_unique_complaint_id_pct": pct(cfpb["Complaint ID"].nunique() / len(cfpb)),
    "cfpb_valid_received_date_pct": pct(cfpb["date_received"].notna().mean()),
    "cfpb_state_az_pct": pct(cfpb["State"].eq("AZ").mean()),
    "cms_unique_facility_id_pct": pct(cms["Facility ID"].nunique() / len(cms)),
    "cms_rating_coverage_pct": pct(cms["rated"].mean()),
    "bls_duplicate_series_date_rows": int(pd.concat([employment_raw, earnings_raw, cpi_raw]).duplicated(["series_id", "date"]).sum()),
}

summary = {
    "portfolio": {
        "raw_rows": int(len(cfpb) + len(cms) + len(employment_raw) + len(earnings_raw) + len(cpi_raw)),
        "datasets": 4,
        "sources": ["Consumer Financial Protection Bureau", "Centers for Medicare & Medicaid Services", "U.S. Bureau of Labor Statistics"],
    },
    "cfpb": {
        "rows": int(len(cfpb)),
        "unique_complaints": int(cfpb["Complaint ID"].nunique()),
        "date_min": str(cfpb["date_received"].min().date()),
        "date_max": str(cfpb["date_received"].max().date()),
        "timely_rate_pct": pct(cfpb["timely"].mean()),
        "top_product": str(cfpb_product.iloc[0]["Product"]),
        "top_product_share_pct": pct(cfpb_product.iloc[0]["share"]),
        "top_5_company_share_pct": pct(cfpb_company.head(5)["complaints"].sum() / len(cfpb)),
        "median_send_lag_hours": round(float(cfpb["send_lag_hours"].median()), 2),
        "peak_month": str(cfpb_monthly.loc[cfpb_monthly["complaints"].idxmax(), "month"]),
        "peak_month_complaints": int(cfpb_monthly["complaints"].max()),
    },
    "cms": {
        "rows": int(len(cms)),
        "unique_facilities": int(cms["Facility ID"].nunique()),
        "rated_facilities": int(cms["rated"].sum()),
        "rating_coverage_pct": pct(cms["rated"].mean()),
        "median_rating": float(cms["rating"].median()),
        "high_quality_shortlist": int(cms["high_quality_flag"].sum()),
        "states_and_territories": int(cms["State"].nunique()),
        "az_hospitals": int(cms["State"].eq("AZ").sum()),
        "az_average_rating": round(float(cms.loc[cms["State"].eq("AZ"), "rating"].mean()), 2),
        "rating_safety_spearman": round(float(cms[["rating", "safety_worse"]].corr(method="spearman").iloc[0, 1]), 3),
    },
    "bls": {
        "raw_rows": int(len(employment_raw) + len(earnings_raw) + len(cpi_raw)),
        "employment_start": str(emp.index.min().date()),
        "employment_latest": str(latest_emp_date.date()),
        "latest_employment_thousands": round(latest_emp, 1),
        "latest_12m_change_thousands": round(latest_emp - year_ago_emp, 1),
        "latest_12m_change_pct": round((latest_emp / year_ago_emp - 1) * 100, 2),
        "pandemic_trough_change_pct": round((emp.loc[pd.Timestamp("2020-04-01")] / feb_2020 - 1) * 100, 2),
        "recovery_date": str(recovery_date.date()),
        "latest_common_date": str(latest_common.date()),
        "latest_real_wage_index": round(float(bls.loc[latest_common, "real_hourly_earnings_index"]), 2),
        **forecast_metrics,
    },
    "quality": quality_checks,
}

(PROCESSED / "summary_metrics.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

print(json.dumps(summary, indent=2))
