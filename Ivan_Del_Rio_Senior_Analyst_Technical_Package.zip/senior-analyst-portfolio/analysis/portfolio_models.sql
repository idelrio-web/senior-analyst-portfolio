-- Ivan Del Rio - Senior Analyst Portfolio
-- Reference SQL patterns aligned to the case-study analytical grains.

-- 1) Data-quality assertion: one complaint per identifier.
select
  count(*) as rows,
  count(distinct complaint_id) as unique_complaints,
  count(*) - count(distinct complaint_id) as duplicate_rows
from stg_cfpb_complaint;

-- 2) Pareto concentration by company.
with company_volume as (
  select
    company,
    count(distinct complaint_id) as complaints,
    avg(case when timely_response = 'Yes' then 1.0 else 0.0 end) as timely_rate
  from fact_complaint
  where state_code = 'AZ'
    and received_date >= date '2024-01-01'
    and received_date < date '2025-01-01'
  group by company
)
select
  *,
  sum(complaints) over (order by complaints desc)
    / nullif(sum(complaints) over (), 0) as cumulative_share
from company_volume
order by complaints desc;

-- 3) Missingness-aware hospital review queue.
select
  facility_id,
  overall_rating,
  safety_measures_worse,
  case
    when overall_rating is null then 'coverage_review'
    when overall_rating >= 4
      and safety_measures_worse = 0
      and emergency_services = 'Yes' then 'high_quality_review'
    else 'standard_review'
  end as review_queue
from fact_hospital_quality;

-- 4) BLS series conformance and rolling anomaly score.
with monthly as (
  select
    series_id,
    period_date,
    value,
    value - lag(value) over (
      partition by series_id order by period_date
    ) as mom_change
  from stg_bls_series
  where period_code between 'M01' and 'M12'
)
select
  *,
  (mom_change - avg(mom_change) over w)
    / nullif(stddev_samp(mom_change) over w, 0) as change_z
from monthly
window w as (
  partition by series_id
  order by period_date
  rows between 35 preceding and current row
);
